module.exports=[378619,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_template-footers_route_actions_8d91975c.js.map