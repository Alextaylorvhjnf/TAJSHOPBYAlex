module.exports=[522692,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_settings_telegram_route_actions_1c44577e.js.map