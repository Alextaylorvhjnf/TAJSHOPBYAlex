module.exports=[617232,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_install_complete_route_actions_6c2781b5.js.map