module.exports=[422879,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_delivery_route_actions_e6e19a19.js.map