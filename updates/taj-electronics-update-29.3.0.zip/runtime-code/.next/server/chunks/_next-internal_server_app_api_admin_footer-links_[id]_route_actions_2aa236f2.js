module.exports=[244276,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_footer-links_%5Bid%5D_route_actions_2aa236f2.js.map