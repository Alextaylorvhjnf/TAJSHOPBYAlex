module.exports=[877462,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_install_storage-init_route_actions_6858e2be.js.map