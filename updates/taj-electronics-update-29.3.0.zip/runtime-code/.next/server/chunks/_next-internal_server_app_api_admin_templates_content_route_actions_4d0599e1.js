module.exports=[700953,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_templates_content_route_actions_4d0599e1.js.map