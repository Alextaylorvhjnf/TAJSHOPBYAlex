module.exports=[497567,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_settings_ai_route_actions_0ef260ae.js.map