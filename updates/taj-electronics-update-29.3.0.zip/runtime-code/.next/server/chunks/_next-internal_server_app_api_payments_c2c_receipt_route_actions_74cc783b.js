module.exports=[38569,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_payments_c2c_receipt_route_actions_74cc783b.js.map