module.exports=[721403,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_cms-pages_%5Bid%5D_route_actions_6cbc9faf.js.map