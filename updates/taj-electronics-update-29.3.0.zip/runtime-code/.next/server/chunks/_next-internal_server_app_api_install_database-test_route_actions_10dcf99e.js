module.exports=[778552,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_install_database-test_route_actions_10dcf99e.js.map