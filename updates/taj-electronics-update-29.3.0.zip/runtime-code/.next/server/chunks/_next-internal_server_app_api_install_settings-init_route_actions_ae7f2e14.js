module.exports=[758375,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_install_settings-init_route_actions_ae7f2e14.js.map