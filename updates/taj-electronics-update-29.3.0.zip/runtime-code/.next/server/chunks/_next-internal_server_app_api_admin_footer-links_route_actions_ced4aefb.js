module.exports=[999125,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_footer-links_route_actions_ced4aefb.js.map