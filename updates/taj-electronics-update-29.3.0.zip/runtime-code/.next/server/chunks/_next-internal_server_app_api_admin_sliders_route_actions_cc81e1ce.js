module.exports=[482664,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_sliders_route_actions_cc81e1ce.js.map