module.exports=[671939,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_settings_payment_route_actions_052c667b.js.map