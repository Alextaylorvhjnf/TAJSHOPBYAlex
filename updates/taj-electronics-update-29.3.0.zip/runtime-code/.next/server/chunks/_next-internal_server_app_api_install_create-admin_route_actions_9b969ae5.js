module.exports=[610649,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_install_create-admin_route_actions_9b969ae5.js.map