module.exports=[624764,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_vertical_route_actions_65c2e4d0.js.map