module.exports=[782182,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_widget-logo_route_actions_d4147583.js.map