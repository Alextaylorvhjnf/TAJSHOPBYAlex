module.exports=[942538,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_products_ai-seo_route_actions_1310967d.js.map