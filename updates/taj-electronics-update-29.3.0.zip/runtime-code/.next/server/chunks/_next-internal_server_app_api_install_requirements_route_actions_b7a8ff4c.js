module.exports=[798565,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_install_requirements_route_actions_b7a8ff4c.js.map