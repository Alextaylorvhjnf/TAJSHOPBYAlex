module.exports=[960706,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_templates_preview_route_actions_05cef459.js.map