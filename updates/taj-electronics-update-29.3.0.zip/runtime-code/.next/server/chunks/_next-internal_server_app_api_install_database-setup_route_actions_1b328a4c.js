module.exports=[7632,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_install_database-setup_route_actions_1b328a4c.js.map