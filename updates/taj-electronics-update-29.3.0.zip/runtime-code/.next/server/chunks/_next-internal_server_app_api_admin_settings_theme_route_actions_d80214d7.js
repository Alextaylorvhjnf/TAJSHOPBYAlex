module.exports=[767299,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_settings_theme_route_actions_d80214d7.js.map