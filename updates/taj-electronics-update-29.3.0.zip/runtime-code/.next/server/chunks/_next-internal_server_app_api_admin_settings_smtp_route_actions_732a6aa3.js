module.exports=[470872,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_settings_smtp_route_actions_732a6aa3.js.map