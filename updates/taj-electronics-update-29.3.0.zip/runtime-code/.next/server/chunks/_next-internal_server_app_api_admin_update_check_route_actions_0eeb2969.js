module.exports=[316337,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_update_check_route_actions_0eeb2969.js.map