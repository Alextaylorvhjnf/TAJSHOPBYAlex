module.exports=[587795,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_sliders_%5Bid%5D_route_actions_81f5e5b5.js.map