module.exports=[692376,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_settings_store_route_actions_efea5bd3.js.map