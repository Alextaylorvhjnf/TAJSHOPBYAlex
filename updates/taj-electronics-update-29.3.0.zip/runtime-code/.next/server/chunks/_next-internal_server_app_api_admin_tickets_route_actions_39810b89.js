module.exports=[384399,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_tickets_route_actions_39810b89.js.map