module.exports=[188175,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_showcases_%5Bid%5D_route_actions_f48c187e.js.map