module.exports=[99526,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_delivery_%5Bid%5D_route_actions_81918489.js.map