module.exports=[195188,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_templates_active_route_actions_c5a43c07.js.map