module.exports=[223553,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_reviews_generate_route_actions_a845f356.js.map