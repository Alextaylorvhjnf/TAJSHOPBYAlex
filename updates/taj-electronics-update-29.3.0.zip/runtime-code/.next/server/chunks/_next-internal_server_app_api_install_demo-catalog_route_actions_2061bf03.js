module.exports=[204044,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_install_demo-catalog_route_actions_2061bf03.js.map