module.exports=[860263,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_orders_%5Bid%5D_route_actions_a352d5c9.js.map