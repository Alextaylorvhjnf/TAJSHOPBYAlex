module.exports=[640837,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_update_status_route_actions_3453edf3.js.map