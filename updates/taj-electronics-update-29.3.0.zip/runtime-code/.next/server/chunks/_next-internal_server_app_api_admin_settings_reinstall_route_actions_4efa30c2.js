module.exports=[259683,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_settings_reinstall_route_actions_4efa30c2.js.map