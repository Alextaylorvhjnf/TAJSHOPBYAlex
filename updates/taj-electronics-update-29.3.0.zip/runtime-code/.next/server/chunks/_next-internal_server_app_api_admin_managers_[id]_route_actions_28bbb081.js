module.exports=[746268,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_managers_%5Bid%5D_route_actions_28bbb081.js.map