var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/categories/route.js")
R.c("server/chunks/[root-of-the-server]__514ce487._.js")
R.c("server/chunks/src_lib_templates_content_ts_995374d9._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_75a964cd._.js")
R.c("server/chunks/_next-internal_server_app_api_categories_route_actions_9c21f11d.js")
R.m(913946)
module.exports=R.m(913946).exports
