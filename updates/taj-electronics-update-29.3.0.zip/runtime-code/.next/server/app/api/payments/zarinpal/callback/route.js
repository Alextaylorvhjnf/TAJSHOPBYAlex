var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/zarinpal/callback/route.js")
R.c("server/chunks/[root-of-the-server]__40659741._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_zarinpal_callback_route_actions_77296a07.js")
R.m(887985)
module.exports=R.m(887985).exports
