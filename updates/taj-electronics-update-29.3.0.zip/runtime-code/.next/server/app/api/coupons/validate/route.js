var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/coupons/validate/route.js")
R.c("server/chunks/[root-of-the-server]__82acd959._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/_next-internal_server_app_api_coupons_validate_route_actions_8678afa7.js")
R.m(555723)
module.exports=R.m(555723).exports
