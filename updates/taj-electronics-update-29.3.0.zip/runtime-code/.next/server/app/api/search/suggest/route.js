var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/search/suggest/route.js")
R.c("server/chunks/[root-of-the-server]__93e741c6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_search_suggest_route_actions_a5c4941d.js")
R.m(836476)
module.exports=R.m(836476).exports
