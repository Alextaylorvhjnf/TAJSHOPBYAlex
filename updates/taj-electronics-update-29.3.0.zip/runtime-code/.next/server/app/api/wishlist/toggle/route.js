var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/wishlist/toggle/route.js")
R.c("server/chunks/[root-of-the-server]__6df42aff._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_wishlist_toggle_route_actions_f92c037d.js")
R.m(454827)
module.exports=R.m(454827).exports
