var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/update/status/route.js")
R.c("server/chunks/[root-of-the-server]__c85cf697._.js")
R.c("server/chunks/[root-of-the-server]__1cafa3b5._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_update_status_route_actions_3453edf3.js")
R.m(514014)
module.exports=R.m(514014).exports
