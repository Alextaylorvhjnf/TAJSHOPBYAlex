var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/messages/route.js")
R.c("server/chunks/[root-of-the-server]__6edf1b71._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_messages_route_actions_f34b0342.js")
R.m(961173)
module.exports=R.m(961173).exports
