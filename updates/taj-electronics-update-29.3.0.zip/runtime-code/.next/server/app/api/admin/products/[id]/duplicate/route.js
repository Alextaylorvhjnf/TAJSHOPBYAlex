var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/products/[id]/duplicate/route.js")
R.c("server/chunks/[root-of-the-server]__534eb5bf._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/ce889_server_app_api_admin_products_[id]_duplicate_route_actions_0fc85406.js")
R.m(556309)
module.exports=R.m(556309).exports
