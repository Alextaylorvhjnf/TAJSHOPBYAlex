var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/orders/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__ef7def19._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_orders_[id]_route_actions_a352d5c9.js")
R.m(262205)
module.exports=R.m(262205).exports
