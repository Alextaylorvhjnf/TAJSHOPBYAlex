var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/ai/reindex/route.js")
R.c("server/chunks/[root-of-the-server]__e7eaa9a9._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_ai_reindex_route_actions_ee0bd8fa.js")
R.m(656682)
module.exports=R.m(656682).exports
