var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/payments/c2c/[id]/reject/route.js")
R.c("server/chunks/[root-of-the-server]__ff43f525._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/ce889_server_app_api_admin_payments_c2c_[id]_reject_route_actions_1decd73e.js")
R.m(996396)
module.exports=R.m(996396).exports
