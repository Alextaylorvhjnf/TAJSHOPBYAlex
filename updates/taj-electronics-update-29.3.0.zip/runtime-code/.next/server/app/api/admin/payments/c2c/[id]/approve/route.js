var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/payments/c2c/[id]/approve/route.js")
R.c("server/chunks/[root-of-the-server]__32523c40._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/ce889_server_app_api_admin_payments_c2c_[id]_approve_route_actions_ddf2f2a3.js")
R.m(396144)
module.exports=R.m(396144).exports
