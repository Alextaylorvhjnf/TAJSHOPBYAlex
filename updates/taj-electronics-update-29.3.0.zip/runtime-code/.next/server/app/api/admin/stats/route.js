var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/stats/route.js")
R.c("server/chunks/[root-of-the-server]__7e5d4387._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_stats_route_actions_05832952.js")
R.m(202068)
module.exports=R.m(202068).exports
