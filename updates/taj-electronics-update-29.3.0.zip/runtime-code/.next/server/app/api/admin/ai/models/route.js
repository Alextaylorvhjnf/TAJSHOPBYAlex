var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/ai/models/route.js")
R.c("server/chunks/[root-of-the-server]__7ea7db88._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/src_lib_verticals_index_ts_98dd52a5._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/src_lib_ai_ts_d1d17df9._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_ai_models_route_actions_e73a5c85.js")
R.m(810197)
module.exports=R.m(810197).exports
