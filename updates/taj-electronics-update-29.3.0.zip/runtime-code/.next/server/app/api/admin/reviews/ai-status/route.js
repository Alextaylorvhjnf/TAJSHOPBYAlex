var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/reviews/ai-status/route.js")
R.c("server/chunks/[root-of-the-server]__fcfaddab._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_reviews_ai-status_route_actions_80337b67.js")
R.m(668218)
module.exports=R.m(668218).exports
