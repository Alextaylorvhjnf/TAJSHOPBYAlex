var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/update/apply/route.js")
R.c("server/chunks/[root-of-the-server]__65b2cd9d._.js")
R.c("server/chunks/[root-of-the-server]__1cafa3b5._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_update_apply_route_actions_04da717f.js")
R.m(56730)
module.exports=R.m(56730).exports
