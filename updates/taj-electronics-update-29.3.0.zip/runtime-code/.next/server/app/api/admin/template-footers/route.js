var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/template-footers/route.js")
R.c("server/chunks/[root-of-the-server]__c4929104._.js")
R.c("server/chunks/_e7f32e71._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_template-footers_route_actions_8d91975c.js")
R.m(739036)
module.exports=R.m(739036).exports
