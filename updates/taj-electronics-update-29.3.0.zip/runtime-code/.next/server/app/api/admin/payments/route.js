var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/payments/route.js")
R.c("server/chunks/[root-of-the-server]__2fc6da29._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_payments_route_actions_fca5d9ff.js")
R.m(915755)
module.exports=R.m(915755).exports
