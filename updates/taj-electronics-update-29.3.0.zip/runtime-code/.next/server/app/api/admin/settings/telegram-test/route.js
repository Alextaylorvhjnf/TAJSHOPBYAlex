var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/settings/telegram-test/route.js")
R.c("server/chunks/[root-of-the-server]__44fd6cb0._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/ce889_server_app_api_admin_settings_telegram-test_route_actions_eb741958.js")
R.m(410609)
module.exports=R.m(410609).exports
