var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/settings/reinstall/route.js")
R.c("server/chunks/[root-of-the-server]__7a719c48._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_settings_reinstall_route_actions_4efa30c2.js")
R.m(107742)
module.exports=R.m(107742).exports
