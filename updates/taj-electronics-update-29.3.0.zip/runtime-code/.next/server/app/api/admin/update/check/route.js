var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/update/check/route.js")
R.c("server/chunks/[root-of-the-server]__3d560f5c._.js")
R.c("server/chunks/[root-of-the-server]__1cafa3b5._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_update_check_route_actions_0eeb2969.js")
R.m(861937)
module.exports=R.m(861937).exports
