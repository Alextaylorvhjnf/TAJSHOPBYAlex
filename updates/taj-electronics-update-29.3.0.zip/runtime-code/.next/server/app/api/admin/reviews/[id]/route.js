var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/reviews/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__4fdccb63._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/_next-internal_server_app_api_admin_reviews_[id]_route_actions_c3b1fbf7.js")
R.m(707836)
module.exports=R.m(707836).exports
