var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/reviews/route.js")
R.c("server/chunks/[root-of-the-server]__92331757._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_reviews_route_actions_0591c84e.js")
R.m(819830)
module.exports=R.m(819830).exports
