var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/templates/route.js")
R.c("server/chunks/[root-of-the-server]__c4929104._.js")
R.c("server/chunks/_207c99c6._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_templates_route_actions_ec109874.js")
R.m(137008)
module.exports=R.m(137008).exports
