var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/logs/route.js")
R.c("server/chunks/[root-of-the-server]__5e07e34d._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_logs_route_actions_0b185978.js")
R.m(419055)
module.exports=R.m(419055).exports
