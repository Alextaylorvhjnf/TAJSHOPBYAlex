var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/backup/route.js")
R.c("server/chunks/[root-of-the-server]__8d24a4de._.js")
R.c("server/chunks/[root-of-the-server]__1cafa3b5._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_backup_route_actions_64e97726.js")
R.m(638427)
module.exports=R.m(638427).exports
