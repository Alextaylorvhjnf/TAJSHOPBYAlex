var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/settings/zarinpal-test/route.js")
R.c("server/chunks/[root-of-the-server]__8b87afc3._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/ce889_server_app_api_admin_settings_zarinpal-test_route_actions_024619c5.js")
R.m(168656)
module.exports=R.m(168656).exports
