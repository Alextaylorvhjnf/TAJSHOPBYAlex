var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/update/poll/route.js")
R.c("server/chunks/[root-of-the-server]__515452a8._.js")
R.c("server/chunks/[root-of-the-server]__1cafa3b5._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_update_poll_route_actions_9daeb581.js")
R.m(139976)
module.exports=R.m(139976).exports
