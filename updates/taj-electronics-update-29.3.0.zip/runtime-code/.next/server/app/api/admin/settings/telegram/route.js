var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/settings/telegram/route.js")
R.c("server/chunks/[root-of-the-server]__71ab4cba._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_b51a0b59.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_settings_telegram_route_actions_1c44577e.js")
R.m(12438)
module.exports=R.m(12438).exports
