var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/brands/route.js")
R.c("server/chunks/[root-of-the-server]__ff0c8383._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_brands_route_actions_edfb1779.js")
R.m(39484)
module.exports=R.m(39484).exports
