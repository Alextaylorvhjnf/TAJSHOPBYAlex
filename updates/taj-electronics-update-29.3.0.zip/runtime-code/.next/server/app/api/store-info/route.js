var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/store-info/route.js")
R.c("server/chunks/[root-of-the-server]__514ce487._.js")
R.c("server/chunks/_bd61f0bc._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/src_lib_templates_content_ts_995374d9._.js")
R.c("server/chunks/_next-internal_server_app_api_store-info_route_actions_cce537ae.js")
R.m(63029)
module.exports=R.m(63029).exports
