var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/test/route.js")
R.c("server/chunks/[root-of-the-server]__995315d8._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/src_lib_verticals_index_ts_98dd52a5._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/src_lib_ai_ts_d1d17df9._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_test_route_actions_d0a2f3b9.js")
R.m(223684)
module.exports=R.m(223684).exports
