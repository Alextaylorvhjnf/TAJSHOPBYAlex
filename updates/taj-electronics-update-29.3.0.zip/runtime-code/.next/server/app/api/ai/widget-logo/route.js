var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/widget-logo/route.js")
R.c("server/chunks/[root-of-the-server]__4290f897._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_widget-logo_route_actions_d4147583.js")
R.m(606700)
module.exports=R.m(606700).exports
