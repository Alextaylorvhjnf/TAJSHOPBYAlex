var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/chat/availability/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_95d72fe1.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__514ce487._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_chat_availability_route_actions_839fd787.js")
R.m(178048)
module.exports=R.m(178048).exports
