var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/addresses/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__6506d939._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/_next-internal_server_app_api_account_addresses_[id]_route_actions_5d546b2b.js")
R.m(544920)
module.exports=R.m(544920).exports
