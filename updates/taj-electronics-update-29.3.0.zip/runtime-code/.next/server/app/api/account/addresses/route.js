var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/addresses/route.js")
R.c("server/chunks/[root-of-the-server]__7f1adefb._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/_next-internal_server_app_api_account_addresses_route_actions_a32f0e4b.js")
R.m(239548)
module.exports=R.m(239548).exports
