var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/recovery-code/route.js")
R.c("server/chunks/[root-of-the-server]__6d41bec3._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_account_recovery-code_route_actions_3daf4b95.js")
R.m(694381)
module.exports=R.m(694381).exports
