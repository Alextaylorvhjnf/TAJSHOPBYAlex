var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/install/requirements/route.js")
R.c("server/chunks/[root-of-the-server]__0712a4aa._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_install_requirements_route_actions_b7a8ff4c.js")
R.m(483527)
module.exports=R.m(483527).exports
