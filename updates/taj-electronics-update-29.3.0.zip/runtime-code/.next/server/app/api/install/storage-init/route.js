var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/install/storage-init/route.js")
R.c("server/chunks/[root-of-the-server]__7ed03a25._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_install_storage-init_route_actions_6858e2be.js")
R.m(434114)
module.exports=R.m(434114).exports
