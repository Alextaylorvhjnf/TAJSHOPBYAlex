var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/install/database-setup/route.js")
R.c("server/chunks/[root-of-the-server]__2c80aa09._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_install_database-setup_route_actions_1b328a4c.js")
R.m(540929)
module.exports=R.m(540929).exports
