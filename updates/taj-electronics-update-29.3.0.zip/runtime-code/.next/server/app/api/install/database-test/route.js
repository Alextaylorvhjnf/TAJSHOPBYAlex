var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/install/database-test/route.js")
R.c("server/chunks/[root-of-the-server]__779f04f8._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_install_database-test_route_actions_10dcf99e.js")
R.m(646510)
module.exports=R.m(646510).exports
