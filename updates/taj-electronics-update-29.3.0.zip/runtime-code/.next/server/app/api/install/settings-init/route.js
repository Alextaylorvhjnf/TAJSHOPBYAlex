var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/install/settings-init/route.js")
R.c("server/chunks/[root-of-the-server]__4dc15040._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_install_settings-init_route_actions_ae7f2e14.js")
R.m(588403)
module.exports=R.m(588403).exports
