var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/install/demo-catalog/route.js")
R.c("server/chunks/[root-of-the-server]__5c3ce774._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_install_demo-catalog_route_actions_2061bf03.js")
R.m(235196)
module.exports=R.m(235196).exports
