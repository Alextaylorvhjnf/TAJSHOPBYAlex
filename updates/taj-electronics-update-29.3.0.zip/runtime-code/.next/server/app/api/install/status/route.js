var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/install/status/route.js")
R.c("server/chunks/[root-of-the-server]__7fa77905._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_install_status_route_actions_43e48b7c.js")
R.m(946435)
module.exports=R.m(946435).exports
