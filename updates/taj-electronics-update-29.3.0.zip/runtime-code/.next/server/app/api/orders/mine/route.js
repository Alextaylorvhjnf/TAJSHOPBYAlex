var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/mine/route.js")
R.c("server/chunks/[root-of-the-server]__fce0d2b4._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_orders_mine_route_actions_cea5b08f.js")
R.m(648747)
module.exports=R.m(648747).exports
