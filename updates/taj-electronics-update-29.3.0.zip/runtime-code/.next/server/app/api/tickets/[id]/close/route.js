var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/tickets/[id]/close/route.js")
R.c("server/chunks/[root-of-the-server]__971141fa._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_tickets_[id]_close_route_actions_f3c18e41.js")
R.m(993988)
module.exports=R.m(993988).exports
