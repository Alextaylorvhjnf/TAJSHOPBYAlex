var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cart/route.js")
R.c("server/chunks/[root-of-the-server]__209533e3._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_cart_route_actions_64d0c949.js")
R.m(658357)
module.exports=R.m(658357).exports
