var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/uploads/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__ee4220b3._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_uploads_[___path]_route_actions_fad48a42.js")
R.m(155318)
module.exports=R.m(155318).exports
