1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/fada33c9e7b60536.js","/_next/static/chunks/a7212fb24124edf0.js","/_next/static/chunks/6dfcdc37f1389b38.js","/_next/static/chunks/73e3194f06db260e.js"],"default"]
3:I[837457,["/_next/static/chunks/fada33c9e7b60536.js","/_next/static/chunks/a7212fb24124edf0.js","/_next/static/chunks/6dfcdc37f1389b38.js","/_next/static/chunks/73e3194f06db260e.js"],"default"]
0:{"buildId":"wmwT461oEykcsL0nXTOl4","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
